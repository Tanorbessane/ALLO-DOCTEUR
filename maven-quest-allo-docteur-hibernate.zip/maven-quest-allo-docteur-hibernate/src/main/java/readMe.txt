----------  REPONSES AUX QUESTIONS  ----------
- QUESTION 1
     "propriété ACID" ( Atomicity, Consistency, Isolation et Durability )en informatique: Il s’agit des propriétés nécessaires pour garantir une transaction informatique. c'est alors
             un ensemble de propriétés qui garantissent qu'une transaction informatique est exécutée de façon fiable. 

- QUESTION 2
     Les transactions sont une fonctionnalité absolument indispensable, permettant de sécuriser une application utilisant une base de données par rapport à des taches effectuées sur cette derniere,
        qui sert d'enveloppe pour le système de transaction natif de l'environnement de déploiement.

- QUESTION 3
    ORM :est un outil de mappage objet-relationnel, il fournit un cadre permettant de mapper un modèle de domaine orienté objet vers une base de données relationnelle il permet aux développeurs 
d’écrire plus facilement des applications dont les données survivent au processus d’application en simplifiant à la fois grandement le code.
-  3 ORM en Java :
    - Hibernate
    - ActiveJDBC
    - Entreprise JavaBeans