/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cours.revisions.singletons;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.cours.revisions.entities.Personne;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 *
 * @author elhad
 */
public class CsvStatisticSingleton  extends AbstractStatisticSingleton {
    final static String personnesCsvPathFile = "personnesCsv.csv";   
    
    private CsvStatisticSingleton() 
    {  
    	extractPersonnesDatas();
    }
     
    private static class SingletonHolder
    {       
        private final static CsvStatisticSingleton instance = new CsvStatisticSingleton();
    }
 
    public static CsvStatisticSingleton getInstance()
    {
        return SingletonHolder.instance;
    }
     
    private List<Personne> createListPersonnes(){ 
    	return  null;
    }
    
    private Personne createPersonneWithFileObject(String[] attributs) {

        return null;

    }

    @Override
    protected void extractPersonnesDatas() {  
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(
                    new FileInputStream(new File(personnesCsvPathFile)), 
                    StandardCharsets.UTF_8));
            for (String line = br.readLine(); line != null; line = br.readLine()) {
            	Personne personne = new Personne();
            	   String[] p = line.split(";");
            	   if (!line.equals("﻿idPersonne;Prenom;Nom;Poids;Taille;Rue;Ville;Code Postal")) {      	        
	                personne.setIdPersonne(Integer.parseInt(p[0]));
	                personne.setPoids(Double.parseDouble(p[3]));
	                personne.setTaille(Double.parseDouble(p[4]));
	                personnes.add(personne);
            	}
            }

        } catch (IOException e) {
            e.printStackTrace();          
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }   	
    }
     
}
