/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cours.revisions.singletons;

import com.cours.revisions.entities.Personne;
import com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author elhad
 */
public class XmlStatisticSingleton extends AbstractStatisticSingleton {

    final String personnesXmlPathFile = "personnesXml.xml";
    final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    private XmlStatisticSingleton() {
        extractPersonnesDatas();
    }

    private static class Singleton {

        private final static XmlStatisticSingleton instance = new XmlStatisticSingleton();
    }

    public static XmlStatisticSingleton getInstance() {
        return Singleton.instance;
    }

    public Personne createPersonneWithFileObject(Element elementPersonne) {
        Personne personne = new Personne();
        personne.setIdPersonne(Integer.parseInt(String.valueOf(elementPersonne.getAttributes().getNamedItem("id").getNodeValue())));
        personne.setPrenom(elementPersonne.getElementsByTagName("prenom").item(0).getChildNodes().item(0).getNodeValue());
        personne.setNom(elementPersonne.getElementsByTagName("nom").item(0).getChildNodes().item(0).getNodeValue());
        personne.setPoids(Double.parseDouble(elementPersonne.getElementsByTagName("poids").item(0).getChildNodes().item(0).getNodeValue()));
        personne.setTaille(Double.parseDouble(elementPersonne.getElementsByTagName("taille").item(0).getChildNodes().item(0).getNodeValue()));
        personne.setRue(elementPersonne.getElementsByTagName("rue").item(0).getChildNodes().item(0).getNodeValue());
        personne.setVille(elementPersonne.getElementsByTagName("ville").item(0).getChildNodes().item(0).getNodeValue());
        personne.setCodePostal(elementPersonne.getElementsByTagName("codePostal").item(0).getChildNodes().item(0).getNodeValue());
        return personne;

    }

    @Override
    protected void extractPersonnesDatas() {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();

            Document document = builder.parse(personnesXmlPathFile);
            // NodeList nodeList = document.getDocumentElement().getChildNodes();
            NodeList nodeList = document.getElementsByTagName("personne");
            final int nbRacineNoeuds = nodeList.getLength();
            for (int i = 0; i < nbRacineNoeuds; i++) {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    final Element elem = (Element) node;
                    Personne personne = createPersonneWithFileObject(elem);
                    personnes.add(personne);
                }
            }
            for (Personne s : personnes) {

                System.out.println(s);
            }

        } catch (ParserConfigurationException ex) {
            Logger.getLogger(XmlStatisticSingleton.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(XmlStatisticSingleton.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(XmlStatisticSingleton.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
