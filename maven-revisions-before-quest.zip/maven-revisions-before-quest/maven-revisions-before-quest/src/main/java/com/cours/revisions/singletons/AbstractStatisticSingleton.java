/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cours.revisions.singletons;

import com.cours.revisions.entities.Personne;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author elhad
 */
public abstract class AbstractStatisticSingleton {

    protected List<Personne> personnes = new ArrayList<>();
    protected ArrayList<Double> lsMoyennePoids = new ArrayList<>();
    protected ArrayList<Double> lstMoyenneTaille = new ArrayList<>();
    protected Double moyennePoids = 0.0;
    protected Double ecartTypePoids = 0.0;
    protected Double variancePoids = 0.0;
    protected Double moyenneTaille = 0.0;
    protected Double ecartTypeTaille = 0.0;
    protected Double varianceTaille = 0.0;

    public Double getMoyennePoids() {
        double total = 0;
        moyennePoids = 0.0;
        for (Personne personne : personnes) {
            total += personne.getPoids();
        }
        moyennePoids = total / personnes.size();
        return moyennePoids;
    }

    public Double getEcartTypePoids() {
        variancePoids = 0.0;
        ecartTypePoids = 0.0;
        for (Personne personne : personnes) {
            variancePoids += Math.pow(personne.getPoids() - getMoyennePoids(), 2);
        }

        ecartTypePoids = Math.sqrt(variancePoids / personnes.size());
        return ecartTypePoids;
    }

    public Double getMoyenneTaille() {
        double total = 0;
        moyenneTaille = 0.0;
        for (Personne personne : personnes) {
            total += personne.getTaille();
        }
        moyenneTaille = total / personnes.size();
        return moyenneTaille;
    }

    public Double getEcartTypeTaille() {
        varianceTaille = 0.0;
        ecartTypeTaille = 0.0;
        for (Personne personne : personnes) {
            varianceTaille += Math.pow(personne.getTaille() - getMoyenneTaille(), 2);
        }

        ecartTypeTaille = Math.sqrt(varianceTaille / personnes.size());
        return ecartTypeTaille;
    }

    public List<Personne> getPersonnes() {
        return personnes;
    }

    protected abstract void extractPersonnesDatas();
}
