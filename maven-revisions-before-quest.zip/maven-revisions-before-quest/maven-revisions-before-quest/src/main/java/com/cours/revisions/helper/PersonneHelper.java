/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cours.revisions.helper;

import com.cours.revisions.entities.Personne;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author elhad
 */
public class PersonneHelper {

    private static List<Personne> personnes = null;

    public PersonneHelper() {
    }

    public List<Personne> createListPersonnes() {

        personnes = new ArrayList<>();
        return personnes;
    }

    public void addPersonne(Integer idPersonne, String prenom, String nom, Double poids, Double taille, String rue, String ville, String codePostal) {

        Personne pers = createPersonne(idPersonne, prenom, nom, poids, taille, rue, ville, codePostal);
        personnes.add(pers);
    }

    public Personne createPersonne(Integer idPersonne, String prenom, String nom, Double poids, Double taille, String rue, String ville, String codePostal) {
        Personne personne = new Personne();
        personne.setIdPersonne(idPersonne);
        personne.setPrenom(prenom);
        personne.setNom(nom);
        personne.setPoids(poids);
        personne.setTaille(taille);
        personne.setRue(rue);
        personne.setVille(ville);
        personne.setCodePostal(codePostal);
        return personne;
    }

    public List<Personne> createListPersonnesReflexive() throws InstantiationException, IllegalAccessException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException {

        Class aClass = ArrayList.class;
        Object object = aClass.newInstance();
        personnes = (List<Personne>) object;

        /*Method method = List.class.getDeclaredMethod("add",Object.class);
        
         Personne personne;// = Personne.class.newInstance();
         PersonneHelper helper = PersonneHelper.class.newInstance();
         List<Class<?>> paramersTypeArgs = Arrays.asList(Integer.class, String.class, String.class, Double.class, Double.class, String.class, String.class, String.class);
         Method addPersonneMethod = PersonneHelper.class.getMethod("addPersonneReflexive", paramersTypeArgs.toArray(new Class<?>[paramersTypeArgs.size()]));
                                                                   
         personne = (Personne) addPersonneMethod.invoke(helper, 1, "Maurice", "Dupont", 100D, 170D, "5 rue du paradis", "Rouen", "76000");
         method.invoke(personnes, personne);
         personne = (Personne) addPersonneMethod.invoke(helper, 2, "Martin", "Marshall ", 55.0, 150.0, " 99 rue de Nantes", "Laval", "53000");
         method.invoke(personnes, personne);
         personne = (Personne) addPersonneMethod.invoke(helper, 3, "Claire ", "Chazal", 65.0, 175.0, "55 rue de Rennes", "Laval", "53000");
         method.invoke(personnes, personne);
         personne = (Personne) addPersonneMethod.invoke(helper, 4, "Celine ", "Dia", 87.0, 170.0, "3 rue Diderot", "Paris", "75000");
         method.invoke(personnes, personne);
         personne = (Personne) addPersonneMethod.invoke(helper, 5, "Remy", "Cheval", 63.0, 140.0, "8 rue du paradis", "Nante", "44000");
         method.invoke(personnes, personne);
         */
        return personnes;
    }

    public Personne addPersonneReflexive(Integer idPersonne, String prenom, String nom, Double poids, Double taille, String rue, String ville, String codePostal) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {

        List<Class<?>> paramersTypeArgs = Arrays.asList(Integer.class, String.class, String.class, Double.class, Double.class, String.class, String.class, String.class);
        Method creationPersonneMethod = PersonneHelper.class.getMethod("createPersonneReflexive", paramersTypeArgs.toArray(new Class<?>[paramersTypeArgs.size()]));
        PersonneHelper helper = PersonneHelper.class.newInstance();
        Personne personne = (Personne) creationPersonneMethod.invoke(helper, idPersonne, prenom, nom, poids, taille, rue, ville, codePostal);
        Method method = List.class.getDeclaredMethod("add", Object.class);
        method.invoke(personnes, personne);
        return personne;
    }

    public Personne createPersonneReflexive(Integer idPersonne, String prenom, String nom, Double poids, Double taille, String rue, String ville, String codePostal) throws IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {

        List<Class<?>> paramersTypeArgs = Arrays.asList(String.class, String.class, Double.class, Double.class, String.class, String.class, String.class);
        Constructor constructor = Personne.class.getConstructor(paramersTypeArgs.toArray(new Class<?>[paramersTypeArgs.size()]));
        return (Personne) constructor.newInstance(prenom, nom, poids, taille, rue, ville, codePostal);

    }

}
