/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cours.revisions.singletons;

import com.cours.revisions.entities.Personne;
import java.io.FileReader;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author elhad
 */
public class JsonStatisticSingleton extends AbstractStatisticSingleton {

    //private IJSON _service; 
    final String personnesJsonPathFile = "personnesJson.json";

    private JsonStatisticSingleton() {
        extractPersonnesDatas();
    }

    private static class SingletonHolder {

        private final static JsonStatisticSingleton instance = new JsonStatisticSingleton();
    }

    public static JsonStatisticSingleton getInstance() {
        return SingletonHolder.instance;
    }

    public Personne createPersonneWithFileObject(JSONObject jsonObjectPerson) {
        Personne personne = new Personne();
        personne.setIdPersonne(Integer.parseInt(String.valueOf(jsonObjectPerson.get("id"))));
        personne.setPoids(Double.parseDouble(String.valueOf(jsonObjectPerson.get("poids"))));
        personne.setTaille(Double.parseDouble(String.valueOf(jsonObjectPerson.get("taille"))));
        return personne;
    }

    @Override
    protected void extractPersonnesDatas() {
        JSONParser parser = new JSONParser();

        try {
            Object obj = parser.parse(new FileReader(personnesJsonPathFile));

            JSONObject jsonObjectBase = (JSONObject) obj;
            JSONArray personList = (JSONArray) jsonObjectBase.get("personnes");

            for (Object o : personList) {
                JSONObject jsonObjectPerson = (JSONObject) o;
                personnes.add(createPersonneWithFileObject(jsonObjectPerson));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
