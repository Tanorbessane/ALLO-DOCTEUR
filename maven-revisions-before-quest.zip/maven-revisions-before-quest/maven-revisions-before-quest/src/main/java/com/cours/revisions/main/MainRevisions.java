/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cours.revisions.main;

import com.cours.revisions.entities.Personne;
import com.cours.revisions.factory.SingletonFactory;
import static com.cours.revisions.factory.SingletonFactory.FactorySingletonType.CSV_SINGLETON_FACTORY;
import static com.cours.revisions.factory.SingletonFactory.FactorySingletonType.XML_SINGLETON_FACTORY;
import com.cours.revisions.helper.PersonneHelper;
import com.cours.revisions.singletons.AbstractStatisticSingleton;
import com.cours.revisions.singletons.CsvStatisticSingleton;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author elhad
 */
public class MainRevisions {

    private static final Log log = LogFactory.getLog(MainRevisions.class);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InstantiationException, IllegalAccessException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException {

        // AbstractStatisticSingleton mySingleton = XmlStatisticSingleton.getInstance();
        AbstractStatisticSingleton mySingleton = SingletonFactory.getFactory(CSV_SINGLETON_FACTORY);
        log.info("#########__<= CSV =>__######### \n");
        System.out.println("moyenne poids : " + mySingleton.getMoyennePoids());
        System.out.println("ecartType poids : " + mySingleton.getEcartTypePoids());
        System.out.println("moyenne taille : " + mySingleton.getMoyenneTaille());
        System.out.println("ecartType taille : " + mySingleton.getEcartTypeTaille() + "\n");

        mySingleton = SingletonFactory.getFactory(XML_SINGLETON_FACTORY);

        log.info("#########__<=XML =>__######### \n");

        System.out.println("moyenne poids : " + mySingleton.getMoyennePoids());
        System.out.println("ecartType poids : " + mySingleton.getEcartTypePoids());
        System.out.println("moyenne poids : " + mySingleton.getMoyennePoids());
        System.out.println("ecartType poids : " + mySingleton.getEcartTypePoids());

        mySingleton = CsvStatisticSingleton.getInstance();

        System.out.println("CSV => \n");
        System.out.println("###################-----#####################");
        System.out.println("moyenne poids : " + mySingleton.getMoyennePoids());

        System.out.println("ecartType poids : " + mySingleton.getEcartTypePoids());
        System.out.println("###################-----#####################");
        System.out.println("moyenne taille : " + mySingleton.getMoyenneTaille());
        System.out.println("ecartType taille : " + mySingleton.getEcartTypeTaille());

        PersonneHelper helper = new PersonneHelper();
        List<Personne> personnes = helper.createListPersonnes();
        helper.addPersonne(1, "Maurice", "Dupont", 100.0, 170.0, "rue du paradis", "Rouen", "76000");
        helper.addPersonne(2, "Martin", "Marshall", 55.0, 150.0, "rue de Nantes", "Laval", "53000");
        helper.addPersonne(3, "Claire", "Chazal", 65.0, 175.0, "rue de Rennes", "Laval", "53000");
        helper.addPersonne(4, "Celine", "Dia", 87.0, 170.0, "rue Diderot", "Paris", "75000");
        helper.addPersonne(5, "Remy", "Cheval", 63.0, 140.0, "rue du paradis", "Nantes", "44000");

        System.out.println("############### The first list ################");
        for (int i = 0; i < personnes.size(); i++) {
            Personne pers = personnes.get(i);
            System.out.println("Element : " + i + " => " + pers.getPrenom());
        }
        List<Personne> personnes2 = helper.createListPersonnesReflexive();
        helper.addPersonneReflexive(1, "Maurice", "Dupont", 100.0, 170.0, "rue du paradis", "Rouen", "76000");
        helper.addPersonneReflexive(2, "Martin", "Marshall", 55.0, 150.0, "rue de Nantes", "Laval", "53000");
        helper.addPersonneReflexive(3, "Claire", "Chazal", 65.0, 175.0, "rue de Rennes", "Laval", "53000");
        helper.addPersonneReflexive(4, "Celine", "Dia", 87.0, 170.0, "rue Diderot", "Paris", "75000");
        helper.addPersonneReflexive(5, "Remy", "Cheval", 63.0, 140.0, "rue du paradis", "Nantes", "44000");
        System.out.println("############### The second list Reflexive ################");
        for (int i = 0; i < personnes2.size(); i++) {
            Personne pers = personnes2.get(i);
            System.out.println("Element : " + i + " => " + pers.getPrenom());
        }

    }
}
