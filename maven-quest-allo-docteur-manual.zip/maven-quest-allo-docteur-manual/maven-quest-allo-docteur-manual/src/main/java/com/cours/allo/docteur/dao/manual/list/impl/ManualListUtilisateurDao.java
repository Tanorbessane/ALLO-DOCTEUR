/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cours.allo.docteur.dao.manual.list.impl;

import com.cours.allo.docteur.dao.DataSource;
import com.cours.allo.docteur.dao.IUtilisateurDao;
import com.cours.allo.docteur.dao.entities.Adresse;
import com.cours.allo.docteur.dao.entities.Utilisateur;
import com.cours.allo.docteur.exception.CustomException;
import com.cours.allo.docteur.factory.AbstractDaoFactory;
import com.cours.allo.docteur.factory.ManualListDaoFactory;
import static com.cours.allo.docteur.utils.Constants.EXCEPTION_CODE_USER_ALREADY_EXIST;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Objects;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author ElHadji
 */
public class ManualListUtilisateurDao extends AbstractListDao<Utilisateur> implements IUtilisateurDao {

    private static final Log log = LogFactory.getLog(ManualListUtilisateurDao.class);
    private AbstractDaoFactory abstractListDao = ManualListDaoFactory.getInstance();
    private List<Utilisateur> listUtilisateurs = DataSource.getInstance().getUtilisateursListDataSource();

    private ManualListUtilisateurDao() {
        super(Utilisateur.class, DataSource.getInstance().getUtilisateursListDataSource());
    }

    private static class SingletonHolder {

        private final static ManualListUtilisateurDao instance = new ManualListUtilisateurDao();
    }

    public static ManualListUtilisateurDao getInstance() {
        return SingletonHolder.instance;
    }

    @Override
    public List<Utilisateur> findAllUtilisateurs() {
        List<Utilisateur> lst_utilisateur;
        lst_utilisateur = listUtilisateurs;
        return lst_utilisateur;
    }

    @Override
    public Utilisateur findUtilisateurById(int idUtilisateur) {
        Iterator<Utilisateur> usersIt;
        Utilisateur curUser;

        usersIt = listUtilisateurs.iterator();

        while (usersIt.hasNext()) {
            curUser = usersIt.next();

            if (curUser.getIdUtilisateur().equals(idUtilisateur)) {
                return curUser;
            }
        }
        return null;
    }

    @Override
    public List<Utilisateur> findUtilisateurByIdentifiant(String identifiant) {
        Iterator<Utilisateur> usersIt;
        List<Utilisateur> result;
        Utilisateur curUser;
        usersIt = listUtilisateurs.iterator();
        result = new ArrayList<>();
        while (usersIt.hasNext()) {
            curUser = usersIt.next();
            if (curUser.getIdentifiant().equals(identifiant)) {
                result.add(curUser);
            }
        }

        return result;
    }

    @Override
    public List<Utilisateur> findUtilisateursByPrenom(String prenom) {
        Iterator<Utilisateur> usersIt;
        List<Utilisateur> result;
        Utilisateur curUser;
        usersIt = listUtilisateurs.iterator();
        result = new ArrayList<>();
        while (usersIt.hasNext()) {
            curUser = usersIt.next();
            if (curUser.getPrenom().equals(prenom)) {
                result.add(curUser);
            }
        }

        return result;
    }

    @Override
    public List<Utilisateur> findUtilisateursByNom(String nom) {
        Iterator<Utilisateur> usersIt;
        List<Utilisateur> result;
        Utilisateur curUser;
        usersIt = listUtilisateurs.iterator();
        result = new ArrayList<>();
        while (usersIt.hasNext()) {
            curUser = usersIt.next();
            if (curUser.getNom().equals(nom)) {
                result.add(curUser);
            }
        }

        return result;
    }

    @Override
    public List<Utilisateur> findUtilisateursByCodePostal(String codePostal) {
        Iterator<Utilisateur> usersIt;
        Iterator<Adresse> addrIt;
        List<Utilisateur> ret;
        boolean userHasPostalCode;
        Utilisateur curUser;

        usersIt = listUtilisateurs.iterator();
        ret = new ArrayList<>();

        while (usersIt.hasNext()) {
            curUser = usersIt.next();
            addrIt = curUser.getAdresses().iterator();
            userHasPostalCode = false;

            while (addrIt.hasNext() && userHasPostalCode == false) {
                userHasPostalCode = addrIt.next().getCodePostal().equals(codePostal);

                if (userHasPostalCode) {
                    ret.add(curUser);
                }
            }
        }

        return ret;
    }

    @Override
    public Utilisateur createUtilisateur(Utilisateur user) {
        Utilisateur lastUser;
        Iterator<Utilisateur> it;

        lastUser = listUtilisateurs.get(listUtilisateurs.size() - 1);
        it = listUtilisateurs.iterator();

        while (it.hasNext()) {
            if (it.next().getIdentifiant().equals(user.getIdentifiant())) {
                throw new CustomException(
                        "L'utilisateur portant l'identitifiant " + user.getIdentifiant() + " existe deja", EXCEPTION_CODE_USER_ALREADY_EXIST);
            }
        }

        listUtilisateurs.add(user);
        listUtilisateurs.get(listUtilisateurs.size() - 1)
                .setIdUtilisateur(lastUser.getIdUtilisateur() + 1);
        listUtilisateurs.get(listUtilisateurs.size() - 1).setDateModification(new Date());
        listUtilisateurs.get(listUtilisateurs.size() - 1).setDateCreation(new Date());

        return listUtilisateurs.get(listUtilisateurs.size() - 1);
    }

    @Override
    public Utilisateur updateUtilisateur(Utilisateur user) {
        Date date = new Date();

        for (Utilisateur utilisateur : listUtilisateurs) {
            if (Objects.equals(utilisateur.getIdUtilisateur(), user.getIdUtilisateur())) {
                utilisateur.setIdUtilisateur(utilisateur.getIdUtilisateur());
                utilisateur.setCivilite(user.getCivilite());
                utilisateur.setPrenom(user.getPrenom());
                utilisateur.setNom(user.getNom());
                utilisateur.setIdentifiant(user.getIdentifiant());
                utilisateur.setMotPasse(user.getMotPasse());
                utilisateur.setDateNaissance(user.getDateNaissance());
                utilisateur.setDateModification(date);
                utilisateur.setAdresses(user.getAdresses());
                utilisateur.setVersion(utilisateur.getVersion() + 1);
                return utilisateur;
            }
        }
        return null;
    }

    @Override
    public boolean deleteUtilisateur(Utilisateur user) throws CustomException {
        if (listUtilisateurs.remove(user)) {
            return true;
        }
        return false;
    }

}
