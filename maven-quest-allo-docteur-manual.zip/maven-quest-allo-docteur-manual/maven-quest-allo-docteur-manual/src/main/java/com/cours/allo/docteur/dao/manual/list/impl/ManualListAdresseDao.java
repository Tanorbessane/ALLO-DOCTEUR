/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cours.allo.docteur.dao.manual.list.impl;

import com.cours.allo.docteur.dao.DataSource;
import com.cours.allo.docteur.dao.IAdresseDao;
import com.cours.allo.docteur.dao.entities.Adresse;
import com.cours.allo.docteur.exception.CustomException;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author ElHadji
 */
public class ManualListAdresseDao extends AbstractListDao<Adresse> implements IAdresseDao {

    private static final Log log = LogFactory.getLog(ManualListAdresseDao.class);
    private List<Adresse> listAdresses = DataSource.getInstance().getAdressesListDataSource();

    private ManualListAdresseDao() {
        super(Adresse.class, DataSource.getInstance().getAdressesListDataSource());
    }

    private static class SingletonHolder {

        private final static ManualListAdresseDao instance = new ManualListAdresseDao();
    }

    public static ManualListAdresseDao getInstance() {
        return SingletonHolder.instance;
    }

    @Override
    public List<Adresse> findAllAdresses() {
        return listAdresses;
    }

    @Override
    public Adresse findAdresseById(int idAdresse) throws CustomException {
        for (Adresse adresse : listAdresses) {
            if (adresse.getIdAdresse().equals(idAdresse)) {
                return adresse;
            }
        }
        return null;
    }

    @Override
    public List<Adresse> findAdressesByVille(String ville) {
        List<Adresse> adressesByVille = null;
        adressesByVille = new ArrayList<>();
        for (Adresse adresse : listAdresses) {
            if (adresse.getVille().equals(ville)) {
                adressesByVille.add(adresse);
            }
        }
        return adressesByVille;
    }

    @Override
    public List<Adresse> findAdressesByCodePostal(String codePostal) {
        List<Adresse> adressesByCode = null;
        adressesByCode = new ArrayList<>();
        for (Adresse adresse : listAdresses) {
            if (adresse.getCodePostal().equals(codePostal)) {
                adressesByCode.add(adresse);
            }
        }
        return adressesByCode;
    }

    @Override
    public Adresse createAdresse(Adresse adresse) {
        int idAdresse = 0;
        idAdresse = listAdresses.get(listAdresses.size() - 1).getIdAdresse();
        adresse.setIdAdresse(idAdresse + 1);
        listAdresses.add(adresse);
        return adresse;
    }

    @Override
    public Adresse updateAdresse(Adresse adresse) {
        for (int i = 0; i < listAdresses.size(); i++) {
            if (listAdresses.get(i).getIdAdresse().equals(adresse.getIdAdresse())) {
                adresse.setVersion(adresse.getVersion() + 1);
                listAdresses.set(i, adresse);
                return adresse;
            }
        }
        return null;
    }

    @Override
    public boolean deleteAdresse(Adresse adresse) {
        for (Adresse adr : listAdresses) {
            if (Objects.equals(adr.getIdAdresse(), adresse.getIdAdresse())) {
                listAdresses.remove(adr);
                return true;
            }
        }
        return false;
    }
}
