/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cours.allo.docteur.dao.manual.array.impl;

import com.cours.allo.docteur.dao.IUtilisateurDao;
import com.cours.allo.docteur.dao.entities.Adresse;
import com.cours.allo.docteur.dao.entities.Utilisateur;
import com.cours.allo.docteur.factory.AbstractDaoFactory;
import com.cours.allo.docteur.factory.ManualArrayDaoFactory;
import com.cours.allo.docteur.dao.DataSource;
import com.cours.allo.docteur.exception.CustomException;
import static com.cours.allo.docteur.utils.Constants.EXCEPTION_CODE_USER_ALREADY_EXIST;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author ElHadji
 */
public class ManualArrayUtilisateurDao extends AbstractArrayDao<Utilisateur> implements IUtilisateurDao {

    private static final Log log = LogFactory.getLog(ManualArrayUtilisateurDao.class);
    private AbstractDaoFactory abstractArrayDao = ManualArrayDaoFactory.getInstance();
    private Utilisateur[] lst_utilisateur = DataSource.getInstance().getUtilisateursArrayDataSource();

    public ManualArrayUtilisateurDao() {
        super(Utilisateur.class, DataSource.getInstance().getUtilisateursArrayDataSource());
    }

    private static class SingletonHolder {

        private final static ManualArrayUtilisateurDao instance = new ManualArrayUtilisateurDao();
    }

    public static ManualArrayUtilisateurDao getInstance() {
        return SingletonHolder.instance;
    }

    @Override
    public List<Utilisateur> findAllUtilisateurs() {
        return Arrays.asList(lst_utilisateur);
    }

    @Override
    public Utilisateur findUtilisateurById(int idUtilisateur) {
        Utilisateur result = null;
        int i = 0;
        while (i < lst_utilisateur.length && result == null) {
            if (lst_utilisateur[i].getIdUtilisateur().equals(idUtilisateur)) {
                result = lst_utilisateur[i];
            }

            i++;
        }

        return result;
    }

    @Override
    public List<Utilisateur> findUtilisateurByIdentifiant(String identifiant) {
        Utilisateur[] utilisateurs;
        Utilisateur[] result;
        int i = 0;
        int size = 0;

        utilisateurs = new Utilisateur[lst_utilisateur.length];

        while (i < lst_utilisateur.length) {
            if (lst_utilisateur[i].getIdentifiant().equals(identifiant)) {
                utilisateurs[size] = lst_utilisateur[i];
                size++;
            }

            i++;
        }

        if (size == 0) {
            throw new CustomException(
                    "L'utilisateur portant le prenom " + identifiant + " n'a pas pu etre trouve", 1);
        }

        result = new Utilisateur[size];
        System.arraycopy(utilisateurs, 0, result, 0, size);

        return Arrays.asList(result);
    }

    @Override
    public List<Utilisateur> findUtilisateursByPrenom(String prenom) {
        Utilisateur[] utilisateurs;
        Utilisateur[] result;
        int i = 0;
        int size = 0;

        utilisateurs = new Utilisateur[lst_utilisateur.length];

        while (i < lst_utilisateur.length) {
            if (lst_utilisateur[i].getPrenom().equals(prenom)) {
                utilisateurs[size] = lst_utilisateur[i];
                size++;
            }

            i++;
        }

        if (size == 0) {
            throw new CustomException(
                    "L'utilisateur ayant comme prenom " + prenom + " n'a pas pu etre trouve", 1);
        }

        result = new Utilisateur[size];
        System.arraycopy(utilisateurs, 0, result, 0, size);

        return Arrays.asList(result);
    }

    @Override
    public List<Utilisateur> findUtilisateursByNom(String nom) {
        Utilisateur[] utilisateurs;
        Utilisateur[] result;
        int i = 0;
        int size = 0;

        utilisateurs = new Utilisateur[lst_utilisateur.length];

        while (i < lst_utilisateur.length) {
            if (lst_utilisateur[i].getNom().equals(nom)) {
                utilisateurs[size] = lst_utilisateur[i];
                size++;
            }

            i++;
        }

        if (size == 0) {
            throw new CustomException(
                    "L'utilisateur ayant comme prenom " + nom + " n'a pas pu etre trouve", 1);
        }

        result = new Utilisateur[size];
        System.arraycopy(utilisateurs, 0, result, 0, size);

        return Arrays.asList(result);
    }

    @Override
    public List<Utilisateur> findUtilisateursByCodePostal(String codePostal) {
        Utilisateur[] utilisateurs;
        Utilisateur[] result;
        Iterator<Adresse> itAddr;
        boolean addrFound;
        int i = 0;
        int sizeTmp = 0;
        int sizeArray;

        sizeArray = lst_utilisateur.length;
        utilisateurs = new Utilisateur[lst_utilisateur.length];

        while (i < sizeArray) {
            addrFound = false;
            itAddr = lst_utilisateur[i].getAdresses().iterator();

            while (itAddr.hasNext() && !addrFound) {
                if (itAddr.next().getCodePostal().equals(codePostal)) {
                    utilisateurs[sizeTmp] = lst_utilisateur[i];
                    sizeTmp++;
                    addrFound = true;
                }
            }

            i++;
        }

        if (sizeTmp == 0) {
            throw new CustomException(
                    "L'utilisateur  " + codePostal + " n'a pas pu etre trouve", 1);
        }

        result = new Utilisateur[sizeTmp];
        System.arraycopy(utilisateurs, 0, result, 0, sizeTmp);

        return Arrays.asList(result);
    }

    @Override
    public Utilisateur createUtilisateur(Utilisateur user) throws CustomException {
        Utilisateur[] utilisateurs;
        int lastId;
        lastId = lst_utilisateur[lst_utilisateur.length - 1].getIdUtilisateur();

        utilisateurs = new Utilisateur[lst_utilisateur.length + 1];
        System.arraycopy(lst_utilisateur,
                0,
                utilisateurs,
                0,
                lst_utilisateur.length);

        user.setIdUtilisateur(lastId + 1);
        user.setDateModification(new Date());
        user.setDateCreation(new Date());

        utilisateurs[lst_utilisateur.length] = user;
        for (Utilisateur n : lst_utilisateur) {
            if (n.getIdentifiant().equals(user.getIdentifiant())) {
                throw new CustomException("Une erreur s'est produite, il existe déjà un utilisateur avec l’identifiant" + user.getIdentifiant() + " dans l’application", EXCEPTION_CODE_USER_ALREADY_EXIST);
            }
        }
        lst_utilisateur = utilisateurs.clone();
        return user;
    }

    @Override
    public Utilisateur updateUtilisateur(Utilisateur user) throws CustomException {
        boolean trouve = false;
        List<Adresse> lst_adresse = AbstractDaoFactory.getFactory(AbstractDaoFactory.FactoryDaoType.MANUAL_ARRAY_DAO_FACTORY).getAdresseDao().findAllAdresses(); //abstractArrayDao.getAdresseDao().findAllAdresses();    		
        Utilisateur[] lst = lst_utilisateur;
        for (int i = 0; i < lst.length; i++) {
            if (lst[i].getIdUtilisateur() == user.getIdUtilisateur()) {
                lst[i].setCivilite(user.getCivilite());
                lst[i].setPrenom(user.getPrenom());
                lst[i].setNom(user.getNom());
                lst[i].setIdentifiant(user.getMotPasse());
                lst[i].setNumeroTelephone(user.getNumeroTelephone());
                lst[i].setDateNaissance(user.getDateNaissance());
                lst[i].setDateCreation(new Date());
                lst[i].setDateModification(new Date());
                lst[i].setActif(user.isActif());
                lst[i].setMarquerEffacer(user.isMarquerEffacer());
                // Adresse à mettre à jour si besoin
                lst[i].setVersion(lst[i].getVersion() + 1);
                for (int j = 0; j < lst_adresse.size(); j++) {
                    Adresse a = lst_adresse.get(j);
                    AbstractDaoFactory.getFactory(AbstractDaoFactory.FactoryDaoType.MANUAL_ARRAY_DAO_FACTORY).getAdresseDao().updateAdresse(a);
                }
                trouve = true;
                break;

            }
        }

        if (trouve == false) {
            throw new CustomException(
                    "L'utilisateur portant l'identifiant " + user.getIdentifiant() + " n'existe pas", 2);

        }
        return user;
    }

    @Override
    public boolean deleteUtilisateur(Utilisateur user) {

        int j = 0;
        int i = 0;
        int size;
        Utilisateur[] u;
        boolean trouve = false;
        size = lst_utilisateur.length;
        u = new Utilisateur[size - 1];

        while (j < size) {
            if (lst_utilisateur[j].getIdUtilisateur().equals(user.
                    getIdUtilisateur())) {
                trouve = true;
            } else {
                u[i] = lst_utilisateur[j];
                i++;
            }

            j++;
        }

        lst_utilisateur = new Utilisateur[size - 1];
        System.arraycopy(u, 0, lst_utilisateur, 0, size - 1);

        return trouve;
    }
}
