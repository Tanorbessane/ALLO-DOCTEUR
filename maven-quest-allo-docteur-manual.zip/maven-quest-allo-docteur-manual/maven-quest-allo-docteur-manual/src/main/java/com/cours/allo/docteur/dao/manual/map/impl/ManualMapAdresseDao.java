/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cours.allo.docteur.dao.manual.map.impl;

import com.cours.allo.docteur.dao.DataSource;
import com.cours.allo.docteur.dao.IAdresseDao;
import com.cours.allo.docteur.dao.entities.Adresse;
import com.cours.allo.docteur.dao.entities.Utilisateur;
import com.cours.allo.docteur.factory.AbstractDaoFactory;
import com.cours.allo.docteur.factory.ManualArrayDaoFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author ElHadji
 */
public class ManualMapAdresseDao extends AbstractMapDao<Adresse> implements IAdresseDao {

    private static final Log log = LogFactory.getLog(ManualMapAdresseDao.class);
    private Map<Integer, Adresse> lst_adresse = DataSource.getInstance().getAdressesMapDataSource();

    private ManualMapAdresseDao() {
        super(Adresse.class, DataSource.getInstance().getAdressesMapDataSource());
    }

    private static class SingletonHolder {

        private final static ManualMapAdresseDao instance = new ManualMapAdresseDao();
    }

    public static ManualMapAdresseDao getInstance() {
        return SingletonHolder.instance;
    }

    @Override
    public List<Adresse> findAllAdresses() {
        return new ArrayList<Adresse>(lst_adresse.values());

    }

    @Override
    public Adresse findAdresseById(int idAdresse) {
        for (Map.Entry<Integer, Adresse> entry : lst_adresse.entrySet()) {
            if (entry.getValue().getIdAdresse().equals(idAdresse)) {
                return entry.getValue();
            }
        }
        return null;
    }

    @Override
    public List<Adresse> findAdressesByVille(String ville) {
        List<Adresse> lst = findAllAdresses();
        List<Adresse> result = new ArrayList<Adresse>();

        for (Adresse u : lst) {
            if (u.getVille().equals(ville)) {
                result.add(u);
            }
        }
        return result;
    }

    @Override
    public List<Adresse> findAdressesByCodePostal(String codePostal) {
        List<Adresse> lst = findAllAdresses();
        List<Adresse> result = new ArrayList<Adresse>();

        for (Adresse u : lst) {
            if (u.getCodePostal().equals(codePostal)) {
                result.add(u);
            }
        }
        return result;
    }

    @Override
    public Adresse createAdresse(Adresse adresse) {
        List sortedKeys = new ArrayList(lst_adresse.keySet());
        Collections.sort(sortedKeys);
        int newId = sortedKeys.size();
        adresse.setIdAdresse(newId + 1);
        lst_adresse.put(newId + 1, adresse);
        return adresse;
    }

    @Override
    public Adresse updateAdresse(Adresse adresse) {
        for (Adresse adr : lst_adresse.values()) {
            if (Objects.equals(adr.getIdAdresse(), adresse.getIdAdresse())) {
                adr.setRue(adresse.getRue());
                adr.setCodePostal(adresse.getCodePostal());
                adr.setVille(adresse.getVille());
                adr.setPays(adresse.getPays());
                adr.setVersion(adresse.getVersion() + 1);
                adr.setIdUtilisateur(adresse.getIdUtilisateur());
                return adr;
            }
        }
        return null;
    }

    @Override
    public boolean deleteAdresse(Adresse adresse) {
        boolean result = false;
        for (Map.Entry<Integer, Adresse> entry : lst_adresse.entrySet()) {
            if (entry.getValue().equals(adresse)) {
                lst_adresse.remove(entry.getKey(), entry.getValue());
                result = true;
                break;
            }
        }
        return result;
    }
}
