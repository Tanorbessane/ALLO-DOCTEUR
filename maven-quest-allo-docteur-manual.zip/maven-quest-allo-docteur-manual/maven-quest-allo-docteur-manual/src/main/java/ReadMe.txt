    -----REPONSES AUX QUESTIONS
- À quoi servent les méthodes toString, equalscode> et hashCode ?
    - toString : c'est méthode définie dans la classe object qui permet d'afficher des informations sur l'objet en question en renvoyant une chaine de caractére. 
    - equalscode : c'est aussi une méthode de la classe Object qui permet de tester l'égalité de deux objets d'un point de vue sémantique.
    - hashCode : permet de renvoyer la valeur de hachage de l'objet sur lequel on l'utilise.Elle sert aussi a pouvoir stocker un objet dans la classe HashTable.

- Différence entre : 
    - List et ArrayList : List est une interface. ArrayList est une classe qui implémente l'interface List.
    - Map et HashMap : Map est une interface,  HashMap est une classe qui implémente l'interface Map.
    - Set et HashSet : Set est une interface,  HashSet est une classe qui implémente l'interface Set.
    - List et Set : List est une collection ordonnée, qui permet généralement de dupliquer on peut alors accéder aux éléments par leur index entier i par exemple et rechercher des éléments dans la liste.
         alors qu'un Set est une collection qui ne contient aucun élément en double. 