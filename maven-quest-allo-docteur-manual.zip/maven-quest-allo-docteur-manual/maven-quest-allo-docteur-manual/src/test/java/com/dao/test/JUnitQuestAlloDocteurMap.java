package com.dao.test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.cours.allo.docteur.factory.AbstractDaoFactory;
import com.cours.allo.docteur.service.ServiceFacade;
import static com.dao.test.JUnitQuestAlloDocteur.serviceFacade;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.BeforeClass;

public class JUnitQuestAlloDocteurMap extends JUnitQuestAlloDocteur {

    private static final Log log = LogFactory.getLog(JUnitQuestAlloDocteurMap.class);

    @BeforeClass
    public static void init() throws Exception {
        log.debug("Entrée JUnitQuestAlloDocteurList");
        serviceFacade = new ServiceFacade(AbstractDaoFactory.FactoryDaoType.MANUAL_MAP_DAO_FACTORY);
        utilisateurs = serviceFacade.getUtilisateurDao().findAllUtilisateurs();
        adresses = serviceFacade.getAdresseDao().findAllAdresses();
    }
}
