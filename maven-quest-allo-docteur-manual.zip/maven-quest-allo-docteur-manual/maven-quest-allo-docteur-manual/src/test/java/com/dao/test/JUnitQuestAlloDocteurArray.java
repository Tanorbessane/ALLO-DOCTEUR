package com.dao.test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.cours.allo.docteur.factory.AbstractDaoFactory;
import com.cours.allo.docteur.service.ServiceFacade;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.BeforeClass;

public class JUnitQuestAlloDocteurArray extends JUnitQuestAlloDocteur {

    private static final Log log = LogFactory.getLog(JUnitQuestAlloDocteurArray.class);
   // private static IServiceFacade serviceFacade = null;
    @BeforeClass
    public static void init() throws Exception {
        log.debug("Entrée JUnitQuestAlloDocteurArray");
        serviceFacade = new ServiceFacade(AbstractDaoFactory.FactoryDaoType.MANUAL_ARRAY_DAO_FACTORY);
        utilisateurs = serviceFacade.getUtilisateurDao().findAllUtilisateurs();
        adresses = serviceFacade.getAdresseDao().findAllAdresses();
    }
    
}
